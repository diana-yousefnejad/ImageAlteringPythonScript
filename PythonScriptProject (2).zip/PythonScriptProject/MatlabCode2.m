
%reads the data from the three different ouput text files (for C, Haskell, and prolog) and stores it into these three variables 

output_variable = fileread('c_output.txt');

output_variable2 = fileread('h_output.txt');

output_variable3 = fileread('s_output.txt');




%converts the strings into numbers and the numbers into pixels (unsigned chars)

output_array = uint8(str2num(output_variable));

output_array2 = uint8(str2num(output_variable2));

output_array3 = uint8(str2num(output_variable3));


%reshapes the array making a matrix

resized_matrix = reshape(output_array, 256, 256);

resized_matrix2 = reshape(output_array2, 256, 256);

resized_matrix3 = reshape(output_array3, 256, 256);



%read text file values put into input_variable
input_variable = fileread('input.txt');

%convert data in input_variable from string to numbers to unsigned char which are pixels (store in input output array)
input_output_array = uint8(str2num(input_variable));


resized_matrix4 = reshape(input_output_array, 256, 256);



%subplot is making a plot that will hold all four images in the output

%original image position in plot (first)
subplot(1,4,1);
%displays original image
imshow(resized_matrix4);
title('Original');


%second image location
subplot(1,4,2);
imshow(resized_matrix);
%title('Black & White Image from C');
title('C Program');


%third image location
subplot(1,4,3);
imshow(resized_matrix2);
%title('Inverted Black and White Image from Haskell');
title('Haskell');


%fourth image location
subplot(1,4,4);
imshow(resized_matrix3);
%title('Rotated Image from Prolog');
title('Prolog');


%shows output for five seconds
pause(5);