#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

//dynamically gets memory (memory allocation)
int *arrayPtr = NULL;
arrayPtr = (int *) malloc((argc - 1) * sizeof(int));

int arg;
int i;

//converts elements to integers and checks their value
for(i = 1; i < argc; i++){
	arrayPtr[i-1] = atoi(argv[i]);
//	arrayPtr[i-1]++;
//	printf("%d ",arrayPtr[i-1]);

	// threshold is 170
	if (arrayPtr[i-1] > 170){ // if greater then 170 makes the value 255 which is black
		printf("%d ",255);
	}
	else{
		printf("%d ",0); // else makes value 0 which is white
	}
}

free(arrayPtr); //frees the memory
return 0;
}
