import subprocess



input_array = ["1", "2", "3", "4", "5"]


# begins C program process
subprocess.run(["gcc", "cprogram.c", "-o", "cprogram"])

# runs C program
process = subprocess.run(["./cprogram"] + input_array, capture_output=True, text=True)

# holds C program output
output_variable = process.stdout.strip()

# prints output
print("C program output:")
print(output_variable)



# begins Haskell program process
subprocess.run(['ghc', 'hprogram.hs'])

# runs Haskell program
process = subprocess.run(['./hprogram'] + [str(x) for x in input_array], text=True, capture_output = True)
result = process.stdout.strip()

# prints output
print("Haskell program output:")
print(result)


# prolog program process

prolog_input = "[" + ",".join(map(str, input_array)) + "]."

# runs prolog program
result = subprocess.run(['swipl', '-q', '-g', 'main', '-t', 'halt', 'sprogram.pl'], input=prolog_input, capture_output=True, text=True)

# holds output of prolog program
output_result = result.stdout.strip()

# prints output
print("Prolog program output:")

print(output_result)

