%base case
reverse_list([], []).

%recursive case
reverse_list([H|T], Output):-
	reverse_list(T, ReversedTail),
	% moves head to end of list
	append(ReversedTail, [H], Output).

%prints the output without the brackets and commas that are of the list format
print1([]):- !.
print1([H|T]):-
	write(H),
	write(' '),
	print1(T).

%calls the reverse list function, and then uses that output to call print in main
main():-
	read(Input),
	reverse_list(Input, Output),
	print1(Output).	
