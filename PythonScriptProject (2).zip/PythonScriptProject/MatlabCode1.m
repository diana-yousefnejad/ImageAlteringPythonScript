%read image
imdata = imread('mickey-1.png');



%for the test image, change 256 by 256 to 250 by 250 in matlab 2
%imdata = imread('test-1.png');

%imdata = im2gray(imdata)



%targetSize = [256, 256];
%imdata = imresize(imdata, targetSize);


%reshape into 1D bc c program expects
imageOneD = reshape(imdata, 1, []);


dlmwrite('input.txt', imageOneD, 'delimiter', ' ');


