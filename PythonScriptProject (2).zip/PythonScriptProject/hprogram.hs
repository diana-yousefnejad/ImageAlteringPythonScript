import System.Environment

subtract1 :: [Int] -> [Int]

-- base case (empty list gives empty list output)
subtract1 [] = []

-- 255 is value for black, reverts the input color (if pixel had value of 0 it would become 255/the complete opposite)
subtract1 (x:xs) = (255 - x) : subtract1 xs


main :: IO()
main = do
	args <- getArgs

	let numbers = map read args :: [Int] -- converts string to int
	    result = subtract1 numbers -- calls subtract1 function
	    -- converts result back to string
	    resultStrings = map show result
	    outputString = unwords resultStrings
	putStrLn outputString -- prints result
	
