import subprocess

# begins MatlabCode1 process from matlab (this is where we read the mickey image, resize it and put it in a trext file)

matlab_executable = "/Applications/MATLAB_R2023b.app/bin/matlab"

matlab_process = subprocess.run([matlab_executable, "-batch", "run('MatlabCode1.m'); pause(1);"], capture_output = True)




# this loads and reads the input.txt file that has the mickey image and reads the values

with open('input.txt', 'r') as file:

	line = file.readline()

	input_array = [int(value) for value in line.split()]
	input_array = [str(element) for element in input_array]





# begins the C program process (compiles C program)
subprocess.run(["gcc", "cprogram.c", "-o", "cprogram"])

# runs the C program
process = subprocess.run(["./cprogram"] + input_array, capture_output=True, text=True)

# holds output
output_variable = process.stdout.strip()

# writes the output into the c_output text file
with open('c_output.txt', 'w') as f:
	f.write(output_variable)





# begins process of Haskell program
subprocess.run(['ghc', 'hprogram.hs'])
process = subprocess.run(['./hprogram'] + [str(x) for x in input_array], text=True, capture_output = True)

# holds the output of the haskell program
output_variable2 = process.stdout.strip()

# writes the output into the haskell text file
with open('h_output.txt', 'w') as f:
        f.write(output_variable2)




# begins prolog program process
prolog_input = "[" + ",".join(map(str, input_array)) + "]."

result  = subprocess.run(['swipl', '-q', '-g', 'main', '-t', 'halt', 'sprogram.pl'], input=prolog_input, capture_output=True, text=True)

# holds output of prolog program
output_variable3 = result.stdout.strip()


# writes prolog output into the s_output text file
with open('s_output.txt', 'w') as f:
        f.write(output_variable3)





# begins matlabcode2 process
matlab_process = subprocess.run([matlab_executable, "-batch", "run('MatlabCode2.m'); pause(10);"], capture_output = True)

